"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";

const MODULES = [
  { href: "/dashboard/bill-killer", label: "Bill Killer" },
  { href: "/dashboard/app-builder", label: "App Builder" },
  { href: "/dashboard/content-engine", label: "Content Engine" },
  { href: "/dashboard/b2b-tool", label: "B2B Positioning" },
];

// Usage credits are illustrative here — wire to Supabase once metering exists.
export default function Sidebar() {
  const pathname = usePathname();

  return (
    <aside className="flex w-56 flex-col justify-between border-r border-neutral-800 bg-neutral-900 p-4">
      <div>
        <div className="mb-6 px-2 text-lg font-semibold tracking-tight">AI Ops</div>
        <nav className="flex flex-col gap-1">
          {MODULES.map((m) => {
            const active = pathname?.startsWith(m.href);
            return (
              <Link
                key={m.href}
                href={m.href}
                className={`rounded-md px-3 py-2 text-sm transition-colors ${
                  active ? "bg-neutral-800 text-white" : "text-neutral-400 hover:bg-neutral-800/60 hover:text-neutral-200"
                }`}
              >
                {m.label}
              </Link>
            );
          })}
        </nav>
      </div>
      <div className="px-2 text-xs text-neutral-500">
        <div className="mb-2 h-1.5 w-full rounded-full bg-neutral-800">
          <div className="h-1.5 w-2/5 rounded-full bg-neutral-300" />
        </div>
        42 / 100 credits
        <Link href="/dashboard/settings" className="mt-3 block hover:text-neutral-300">
          Settings
        </Link>
      </div>
    </aside>
  );
}
