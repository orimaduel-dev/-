import Anthropic from "@anthropic-ai/sdk";

const client = new Anthropic({ apiKey: process.env.ANTHROPIC_API_KEY });

export type ModelTier = "reasoning" | "fast";

// Central place to change models later without touching every route.
const MODEL_MAP: Record<ModelTier, string> = {
  reasoning: "claude-sonnet-4-6", // Bill Analyzer, Niche Validator, B2B tool, App Builder codegen
  fast: "claude-haiku-4-5-20251001", // App Builder chat turns, quick reflections
};

interface AskOptions {
  system: string;
  user: string;
  tier?: ModelTier;
  maxTokens?: number;
}

/**
 * Single entry point for all Claude calls in the app.
 * Keeps retry/error handling and model selection in one place.
 */
export async function askClaude({ system, user, tier = "reasoning", maxTokens = 2000 }: AskOptions) {
  const model = MODEL_MAP[tier];

  const response = await client.messages.create({
    model,
    max_tokens: maxTokens,
    system,
    messages: [{ role: "user", content: user }],
  });

  const textBlock = response.content.find((block) => block.type === "text");
  if (!textBlock || textBlock.type !== "text") {
    throw new Error("Claude returned no text content");
  }
  return textBlock.text;
}

/** Parses a JSON-only Claude response, stripping accidental markdown fences. */
export function parseJsonResponse<T>(raw: string): T {
  const cleaned = raw.replace(/^```json\s*/i, "").replace(/```\s*$/, "").trim();
  return JSON.parse(cleaned) as T;
}
