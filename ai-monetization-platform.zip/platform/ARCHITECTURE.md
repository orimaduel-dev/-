# AI Monetization Platform — Architecture & UX Plan

## Step 1 — Tech Stack

**Core:** Next.js 14 (App Router, TypeScript) — one codebase, server actions + API routes, deploys clean on Vercel.

| Layer | Choice | Why |
|---|---|---|
| Frontend | Next.js 14 + React Server Components | SSR for fast first paint, API routes live in the same repo |
| Styling | Tailwind CSS + shadcn/ui | Fast, consistent, no design-system debt |
| Auth + DB | Supabase (Postgres + Auth + Storage) | Free tier viable at launch, row-level security fits multi-tenant SaaS, Storage handles uploaded bills/contracts |
| AI | Anthropic SDK (`@anthropic-ai/sdk`), Claude Sonnet for reasoning-heavy modules (Bill Analyzer, B2B), Claude Haiku for lighter/faster ones (App Builder chat, niche brainstorm) | Cost control — route by task complexity |
| File parsing | `pdf-parse` (PDFs) + Claude vision (images of bills) | Bills arrive as both scanned images and PDFs |
| Payments | Stripe (subscriptions + metered usage for AI calls) | Standard, handles both flat-fee and usage-based tiers |
| State | Zustand (client) + Supabase realtime where needed (e.g. App Builder chat) | Lightweight, no Redux overhead |
| Hosting | Vercel (app) + Supabase (data) | Zero-ops for MVP |

**Repo layout (single Next.js app, modular by feature):**

```
/app
  /dashboard
    /bill-killer
    /app-builder
    /content-engine
    /b2b-tool
  /api
    /bill-analyzer
    /app-builder
    /content-engine
    /b2b-tool
/lib
  /prompts        <- one file per module, versioned system prompts
  anthropic.ts    <- single wrapped client, model routing, retries
  supabase.ts
/components
  Sidebar.tsx
  UsageMeter.tsx
  ...
/supabase
  schema.sql
```

One app, four modules as routes — not four separate apps. Shared billing, shared auth, shared usage metering. This matters because a user monetizing AI tools is your ideal customer for cross-selling between modules (e.g., someone using the Niche Validator is also a candidate for the B2B tool).

---

## Step 2 — UI/UX Outline

**Shell:** persistent left sidebar (module switcher + usage meter + settings/billing), top bar shows current module + credits remaining. Content area is full-width per module — each module gets its own workflow shape, not a forced-common template, because the four jobs are genuinely different (upload→analyze, chat→build, wizard→brainstorm, form→generate).

```
┌─────────────┬──────────────────────────────────────────┐
│  Logo        │  Module title            Credits: 42/100 │
│──────────────┤──────────────────────────────────────────┤
│ ▸ Bill Killer│                                            │
│ ▸ App Builder│         [ Module workspace ]               │
│ ▸ Content Eng│                                            │
│ ▸ B2B Tool   │                                            │
│──────────────│                                            │
│ Usage: ▓▓▓░░ │                                            │
│ Settings     │                                            │
└─────────────┴──────────────────────────────────────────┘
```

### Module 1 — Bill Killer (Bill & Contract Analyzer)
1. Drag-drop upload (PDF/image) → Supabase Storage.
2. Extraction step: show a progress state ("Reading your bill…") while Claude parses.
3. Results view: line-item table with flags (⚠ overcharge, 🚩 predatory clause) next to each item, plain-language explanation on click.
4. "Generate dispute letter" button → editable letter draft, copy/export/send.

### Module 2 — App Builder Assistant
1. Chat-first interface ("Yap session") — no blank canvas, an opening prompt asks what they're trying to build.
2. As the conversation progresses, a live spec panel on the right fills in (inputs, logic, outputs) so the user sees their vague description turning into a concrete plan.
3. "Generate" produces a working HTML/JS snippet or API call spec, shown in a code/preview tab.

### Module 3 — Content & Knowledge Engine
1. Wizard, 4 short steps: skills → hobbies → work history → daily routine (each one screen, no long form).
2. Processing screen while Claude cross-references inputs against niche viability.
3. Results: ranked niche list, each expandable into 10 title ideas, thumbnail concepts, and a script outline — collapsed by default so the ranked list stays scannable.

### Module 4 — B2B Positioning Tool
1. Form: describe your service, current clients, price point.
2. Output tabs: Dream Client Profile / Outreach Script (Loom-style) / Proposal Template — generated together, reviewed as tabs rather than one long scroll.

**Cross-cutting:** every module writes its inputs/outputs to Supabase so results persist and reappear on return visits — nobody wants to regenerate a dispute letter because they closed the tab.

---

## Notes on scope for the starter code

The code in this bundle gives you: the routing skeleton, the Anthropic client wrapper with model routing, the four system prompts (production-ready, not placeholders), one working API route per module, and one working UI page per module wired to its route. It does not include Stripe billing wiring or Supabase RLS policies in full — those are noted as TODOs in `supabase/schema.sql` since they depend on your pricing tiers.
