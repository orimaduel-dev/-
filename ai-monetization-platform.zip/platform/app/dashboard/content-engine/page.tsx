"use client";

import { useState } from "react";

const STEPS = ["skills", "hobbies", "workHistory", "dailyRoutine"] as const;
type Field = (typeof STEPS)[number];

const LABELS: Record<Field, string> = {
  skills: "What are you actually good at?",
  hobbies: "What do you do for fun?",
  workHistory: "What jobs have you had?",
  dailyRoutine: "What does a normal day look like for you?",
};

export default function ContentEnginePage() {
  const [step, setStep] = useState(0);
  const [answers, setAnswers] = useState<Record<Field, string>>({
    skills: "",
    hobbies: "",
    workHistory: "",
    dailyRoutine: "",
  });
  const [result, setResult] = useState<any>(null);
  const [loading, setLoading] = useState(false);

  const field = STEPS[step];

  async function submit() {
    setLoading(true);
    const res = await fetch("/api/content-engine", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(answers),
    });
    const data = await res.json();
    setResult(data.result);
    setLoading(false);
  }

  if (result) {
    return (
      <div className="mx-auto max-w-3xl space-y-6 p-8">
        <h1 className="text-2xl font-semibold">Your niches</h1>
        {result.niches?.map((n: any, i: number) => (
          <div key={i} className="rounded-lg border border-neutral-800 p-4">
            <h2 className="font-medium">{n.name}</h2>
            <p className="text-sm text-neutral-400">{n.rationale}</p>
            <p className="mt-1 text-xs text-neutral-500">
              Audience: {n.audience_size} · Competition: {n.competition}
            </p>
          </div>
        ))}
        {result.top_niche && (
          <div className="rounded-lg border border-neutral-700 p-4">
            <h2 className="mb-2 font-medium">Top pick: {result.top_niche}</h2>
            <ul className="list-inside list-disc text-sm text-neutral-300">
              {result.video_titles?.map((t: string, i: number) => (
                <li key={i}>{t}</li>
              ))}
            </ul>
          </div>
        )}
      </div>
    );
  }

  return (
    <div className="mx-auto max-w-xl p-8">
      <h1 className="mb-6 text-2xl font-semibold">Content Engine</h1>
      <p className="mb-2 text-sm text-neutral-400">
        Step {step + 1} of {STEPS.length}
      </p>
      <label className="mb-2 block font-medium">{LABELS[field]}</label>
      <textarea
        className="h-32 w-full rounded-md border border-neutral-800 bg-neutral-900 p-3 text-sm"
        value={answers[field]}
        onChange={(e) => setAnswers({ ...answers, [field]: e.target.value })}
      />
      <div className="mt-4 flex justify-end gap-2">
        {step < STEPS.length - 1 ? (
          <button onClick={() => setStep(step + 1)} className="rounded-md bg-neutral-100 px-4 py-2 text-sm text-neutral-900">
            Next
          </button>
        ) : (
          <button onClick={submit} disabled={loading} className="rounded-md bg-neutral-100 px-4 py-2 text-sm text-neutral-900">
            {loading ? "Analyzing…" : "Find my niche"}
          </button>
        )}
      </div>
    </div>
  );
}
