"use client";

import { useState } from "react";

interface BillFlag {
  type: "overcharge" | "predatory_clause";
  line_item_or_clause: string;
  explanation: string;
  severity: "low" | "medium" | "high";
}

interface BillAnalysis {
  document_type: string;
  billing_party: string;
  flags: BillFlag[];
  confidence: "high" | "medium" | "low";
  notes: string;
}

type Stage = "upload" | "analyzing" | "results";

export default function BillKillerPage() {
  const [stage, setStage] = useState<Stage>("upload");
  const [analysis, setAnalysis] = useState<BillAnalysis | null>(null);
  const [letter, setLetter] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);

  // NOTE: this assumes text extraction (pdf-parse / OCR) already happened
  // and produced `extractedText`. In production, add a small pre-step here:
  // upload file -> POST /api/extract-text -> get extractedText -> call this.
  async function analyze(extractedText: string) {
    setStage("analyzing");
    setError(null);
    try {
      const res = await fetch("/api/bill-analyzer", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ extractedText }),
      });
      if (!res.ok) throw new Error("Analysis request failed");
      const data = await res.json();
      setAnalysis(data.analysis);
      setLetter(data.disputeLetter);
      setStage("results");
    } catch (e) {
      setError("Something went wrong analyzing this document. Try again.");
      setStage("upload");
    }
  }

  function handleFile(e: React.ChangeEvent<HTMLInputElement>) {
    const file = e.target.files?.[0];
    if (!file) return;
    // Placeholder: read as text for .txt testing. Swap for real
    // pdf-parse/vision extraction before wiring up production uploads.
    const reader = new FileReader();
    reader.onload = () => analyze(String(reader.result));
    reader.readAsText(file);
  }

  return (
    <div className="mx-auto max-w-3xl p-8">
      <h1 className="mb-1 text-2xl font-semibold">Bill Killer</h1>
      <p className="mb-6 text-sm text-neutral-400">Upload a bill, lease, or contract. We'll flag what's wrong with it.</p>

      {stage === "upload" && (
        <label className="flex cursor-pointer flex-col items-center justify-center rounded-lg border border-dashed border-neutral-700 p-12 text-neutral-400 hover:border-neutral-500">
          <span>Drop a PDF or image here, or click to browse</span>
          <input type="file" accept=".pdf,.txt,image/*" className="hidden" onChange={handleFile} />
        </label>
      )}

      {stage === "analyzing" && <p className="text-neutral-400">Reading your document…</p>}

      {error && <p className="text-red-400">{error}</p>}

      {stage === "results" && analysis && (
        <div className="space-y-6">
          <div className="rounded-lg border border-neutral-800 p-4">
            <p className="text-sm text-neutral-400">
              {analysis.document_type} — {analysis.billing_party}
            </p>
            <p className="mt-1 text-xs text-neutral-500">Confidence: {analysis.confidence}</p>
          </div>

          <div>
            <h2 className="mb-2 font-medium">Flags ({analysis.flags.length})</h2>
            {analysis.flags.length === 0 && <p className="text-sm text-neutral-500">Nothing suspicious found.</p>}
            <ul className="space-y-2">
              {analysis.flags.map((f, i) => (
                <li key={i} className="rounded-md border border-neutral-800 p-3 text-sm">
                  <span className="mr-2">{f.type === "overcharge" ? "⚠" : "🚩"}</span>
                  <strong>{f.line_item_or_clause}</strong> — {f.explanation}
                </li>
              ))}
            </ul>
          </div>

          {letter && (
            <div>
              <h2 className="mb-2 font-medium">Dispute letter</h2>
              <textarea readOnly value={letter} className="h-64 w-full rounded-md border border-neutral-800 bg-neutral-900 p-3 text-sm" />
            </div>
          )}
        </div>
      )}
    </div>
  );
}
