"use client";

import { useState } from "react";

interface Msg {
  role: "user" | "assistant";
  content: string;
}

export default function AppBuilderPage() {
  const [messages, setMessages] = useState<Msg[]>([
    { role: "assistant", content: "Tell me what you're trying to build — just describe it however makes sense to you." },
  ]);
  const [input, setInput] = useState("");
  const [loading, setLoading] = useState(false);

  async function send() {
    if (!input.trim()) return;
    const next = [...messages, { role: "user" as const, content: input }];
    setMessages(next);
    setInput("");
    setLoading(true);

    const transcript = next.map((m) => `${m.role}: ${m.content}`).join("\n");
    const res = await fetch("/api/app-builder", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ transcript }),
    });
    const data = await res.json();
    setMessages([...next, { role: "assistant", content: data.reply }]);
    setLoading(false);
  }

  return (
    <div className="mx-auto flex h-full max-w-2xl flex-col p-8">
      <h1 className="mb-4 text-2xl font-semibold">App Builder</h1>
      <div className="flex-1 space-y-3 overflow-y-auto">
        {messages.map((m, i) => (
          <div key={i} className={`rounded-lg p-3 text-sm ${m.role === "user" ? "ml-8 bg-neutral-800" : "mr-8 bg-neutral-900 border border-neutral-800"}`}>
            {m.content}
          </div>
        ))}
        {loading && <p className="text-xs text-neutral-500">thinking…</p>}
      </div>
      <div className="mt-4 flex gap-2">
        <input
          value={input}
          onChange={(e) => setInput(e.target.value)}
          onKeyDown={(e) => e.key === "Enter" && send()}
          className="flex-1 rounded-md border border-neutral-800 bg-neutral-900 p-3 text-sm"
          placeholder="Describe what you want to build…"
        />
        <button onClick={send} className="rounded-md bg-neutral-100 px-4 py-2 text-sm text-neutral-900">
          Send
        </button>
      </div>
    </div>
  );
}
