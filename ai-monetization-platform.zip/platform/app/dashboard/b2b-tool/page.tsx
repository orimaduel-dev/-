"use client";

import { useState } from "react";

export default function B2BToolPage() {
  const [form, setForm] = useState({ serviceDescription: "", clientExamples: "", pricePoint: "" });
  const [result, setResult] = useState<any>(null);
  const [loading, setLoading] = useState(false);

  async function submit() {
    setLoading(true);
    const res = await fetch("/api/b2b-tool", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(form),
    });
    const data = await res.json();
    setResult(data.result);
    setLoading(false);
  }

  return (
    <div className="mx-auto max-w-2xl space-y-6 p-8">
      <h1 className="text-2xl font-semibold">B2B Positioning</h1>

      {!result && (
        <div className="space-y-4">
          <div>
            <label className="mb-1 block text-sm font-medium">What do you sell, and to whom?</label>
            <textarea
              className="h-24 w-full rounded-md border border-neutral-800 bg-neutral-900 p-3 text-sm"
              onChange={(e) => setForm({ ...form, serviceDescription: e.target.value })}
            />
          </div>
          <div>
            <label className="mb-1 block text-sm font-medium">Current or past clients (optional)</label>
            <textarea
              className="h-20 w-full rounded-md border border-neutral-800 bg-neutral-900 p-3 text-sm"
              onChange={(e) => setForm({ ...form, clientExamples: e.target.value })}
            />
          </div>
          <div>
            <label className="mb-1 block text-sm font-medium">Target price point</label>
            <input
              className="w-full rounded-md border border-neutral-800 bg-neutral-900 p-3 text-sm"
              onChange={(e) => setForm({ ...form, pricePoint: e.target.value })}
            />
          </div>
          <button onClick={submit} disabled={loading} className="rounded-md bg-neutral-100 px-4 py-2 text-sm text-neutral-900">
            {loading ? "Generating…" : "Generate positioning"}
          </button>
        </div>
      )}

      {result && (
        <div className="space-y-6">
          <div className="rounded-lg border border-neutral-800 p-4">
            <h2 className="mb-2 font-medium">Dream Client Profile</h2>
            <p className="text-sm text-neutral-300">{result.dream_client_profile?.core_pain}</p>
            <p className="mt-1 text-xs text-neutral-500">Trigger: {result.dream_client_profile?.trigger_event}</p>
          </div>
          <div className="rounded-lg border border-neutral-800 p-4">
            <h2 className="mb-2 font-medium">Outreach Script</h2>
            <p className="whitespace-pre-wrap text-sm text-neutral-300">{result.outreach_script}</p>
          </div>
          <div className="rounded-lg border border-neutral-800 p-4">
            <h2 className="mb-2 font-medium">Proposal — Investment</h2>
            <p className="text-sm text-neutral-300">{result.proposal_template?.investment}</p>
          </div>
        </div>
      )}
    </div>
  );
}
