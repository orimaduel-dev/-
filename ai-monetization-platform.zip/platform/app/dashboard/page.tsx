import Link from "next/link";

const MODULES = [
  { href: "/dashboard/bill-killer", title: "Bill Killer", desc: "Find billing errors and generate dispute letters." },
  { href: "/dashboard/app-builder", title: "App Builder", desc: "Describe a tool in plain language, get working code." },
  { href: "/dashboard/content-engine", title: "Content Engine", desc: "Find a profitable content niche from your real background." },
  { href: "/dashboard/b2b-tool", title: "B2B Positioning", desc: "Define your dream client and outreach assets." },
];

export default function DashboardHome() {
  return (
    <div className="mx-auto max-w-3xl p-8">
      <h1 className="mb-6 text-2xl font-semibold">Choose a tool</h1>
      <div className="grid grid-cols-2 gap-4">
        {MODULES.map((m) => (
          <Link key={m.href} href={m.href} className="rounded-lg border border-neutral-800 p-5 hover:border-neutral-600">
            <h2 className="font-medium">{m.title}</h2>
            <p className="mt-1 text-sm text-neutral-400">{m.desc}</p>
          </Link>
        ))}
      </div>
    </div>
  );
}
