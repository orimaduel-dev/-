import "./globals.css";
import Sidebar from "@/components/Sidebar";

export const metadata = {
  title: "AI Ops Platform",
  description: "Bill Killer, App Builder, Content Engine, and B2B Positioning — one dashboard.",
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en">
      <body className="flex h-screen bg-neutral-950 text-neutral-100">
        <Sidebar />
        <main className="flex-1 overflow-y-auto">{children}</main>
      </body>
    </html>
  );
}
