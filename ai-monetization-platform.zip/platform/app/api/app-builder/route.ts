import { NextRequest, NextResponse } from "next/server";
import { askClaude } from "@/lib/anthropic";
import { APP_BUILDER_CHAT_PROMPT, APP_BUILDER_CODEGEN_PROMPT } from "@/lib/prompts";
import { getUser, supabaseServer } from "@/lib/supabase";

// Two actions on one route: "chat" for the yap-session conversation,
// "generate" to turn a captured spec into a working HTML file.
export async function POST(req: NextRequest) {
  try {
    const user = await getUser();
    if (!user) return NextResponse.json({ error: "Not authenticated" }, { status: 401 });

    const body = await req.json();
    const supabase = supabaseServer();

    if (body.action === "generate") {
      const { spec, sessionId } = body;
      if (!spec) return NextResponse.json({ error: "spec is required" }, { status: 400 });

      const html = await askClaude({
        system: APP_BUILDER_CODEGEN_PROMPT,
        user: JSON.stringify(spec),
        tier: "reasoning",
        maxTokens: 4000,
      });

      // Update the existing session row if we have one, else create it.
      if (sessionId) {
        await supabase.from("app_builder_sessions").update({ spec, generated_html: html }).eq("id", sessionId).eq("user_id", user.id);
      } else {
        await supabase.from("app_builder_sessions").insert({ user_id: user.id, spec, generated_html: html });
      }

      return NextResponse.json({ html });
    }

    // Default: chat turn. Client sends full running transcript as `messages`
    // (array of {role, content}); we fold it into one user turn here for
    // simplicity — swap for multi-turn `messages` array once conversation
    // history is stored server-side.
    const { transcript } = body;
    if (!transcript) return NextResponse.json({ error: "transcript is required" }, { status: 400 });

    const reply = await askClaude({
      system: APP_BUILDER_CHAT_PROMPT,
      user: transcript,
      tier: "fast",
      maxTokens: 600,
    });

    const { sessionId } = body;
    if (sessionId) {
      await supabase.from("app_builder_sessions").update({ transcript: body.messages ?? null }).eq("id", sessionId).eq("user_id", user.id);
    }

    return NextResponse.json({ reply });
  } catch (err) {
    console.error("app-builder error", err);
    return NextResponse.json({ error: "Request failed" }, { status: 500 });
  }
}
