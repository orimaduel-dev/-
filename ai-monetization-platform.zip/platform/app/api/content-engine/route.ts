import { NextRequest, NextResponse } from "next/server";
import { askClaude, parseJsonResponse } from "@/lib/anthropic";
import { NICHE_VALIDATOR_PROMPT } from "@/lib/prompts";
import { getUser, supabaseServer } from "@/lib/supabase";

interface WizardInput {
  skills: string;
  hobbies: string;
  workHistory: string;
  dailyRoutine: string;
}

export async function POST(req: NextRequest) {
  try {
    const user = await getUser();
    if (!user) return NextResponse.json({ error: "Not authenticated" }, { status: 401 });

    const input = (await req.json()) as WizardInput;
    const { skills, hobbies, workHistory, dailyRoutine } = input;
    if (!skills || !hobbies || !workHistory || !dailyRoutine) {
      return NextResponse.json({ error: "All four wizard fields are required" }, { status: 400 });
    }

    const userPrompt = `Skills: ${skills}\nHobbies: ${hobbies}\nPast job experience: ${workHistory}\nDaily routine: ${dailyRoutine}`;

    const raw = await askClaude({
      system: NICHE_VALIDATOR_PROMPT,
      user: userPrompt,
      tier: "reasoning",
      maxTokens: 3000,
    });

    const result = parseJsonResponse(raw);

    const supabase = supabaseServer();
    const { error: dbError } = await supabase.from("content_niche_results").insert({
      user_id: user.id,
      inputs: input,
      result,
    });
    if (dbError) console.error("content_niche_results insert failed", dbError);

    return NextResponse.json({ result });
  } catch (err) {
    console.error("content-engine error", err);
    return NextResponse.json({ error: "Niche analysis failed" }, { status: 500 });
  }
}
