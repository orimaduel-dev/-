import { NextRequest, NextResponse } from "next/server";
import { askClaude, parseJsonResponse } from "@/lib/anthropic";
import { B2B_POSITIONING_PROMPT } from "@/lib/prompts";
import { getUser, supabaseServer } from "@/lib/supabase";

interface B2BInput {
  serviceDescription: string;
  clientExamples: string;
  pricePoint: string;
}

export async function POST(req: NextRequest) {
  try {
    const user = await getUser();
    if (!user) return NextResponse.json({ error: "Not authenticated" }, { status: 401 });

    const { serviceDescription, clientExamples, pricePoint } = (await req.json()) as B2BInput;
    if (!serviceDescription || !pricePoint) {
      return NextResponse.json({ error: "serviceDescription and pricePoint are required" }, { status: 400 });
    }

    const userPrompt = `Service description: ${serviceDescription}\nCurrent/past client examples: ${clientExamples || "none provided"}\nTarget price point: ${pricePoint}`;

    const raw = await askClaude({
      system: B2B_POSITIONING_PROMPT,
      user: userPrompt,
      tier: "reasoning",
      maxTokens: 2500,
    });

    const result = parseJsonResponse(raw);

    const supabase = supabaseServer();
    const { error: dbError } = await supabase.from("b2b_positioning_results").insert({
      user_id: user.id,
      inputs: { serviceDescription, clientExamples, pricePoint },
      result,
    });
    if (dbError) console.error("b2b_positioning_results insert failed", dbError);

    return NextResponse.json({ result });
  } catch (err) {
    console.error("b2b-tool error", err);
    return NextResponse.json({ error: "Positioning generation failed" }, { status: 500 });
  }
}
