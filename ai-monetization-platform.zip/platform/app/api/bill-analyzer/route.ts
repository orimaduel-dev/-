import { NextRequest, NextResponse } from "next/server";
import { askClaude, parseJsonResponse } from "@/lib/anthropic";
import { BILL_ANALYZER_PROMPT, DISPUTE_LETTER_PROMPT } from "@/lib/prompts";
import { getUser, supabaseServer } from "@/lib/supabase";

interface BillFlag {
  type: "overcharge" | "predatory_clause";
  line_item_or_clause: string;
  explanation: string;
  severity: "low" | "medium" | "high";
}

interface BillAnalysis {
  document_type: string;
  billing_party: string;
  line_items: unknown[];
  flags: BillFlag[];
  stated_total: number | null;
  computed_total: number | null;
  confidence: "high" | "medium" | "low";
  notes: string;
}

// Expects { extractedText: string } — text extraction from PDF/image
// happens client-side or in a separate /api/extract-text route using
// pdf-parse (PDF) or a vision call (image), then is passed here.
export async function POST(req: NextRequest) {
  try {
    const user = await getUser();
    if (!user) return NextResponse.json({ error: "Not authenticated" }, { status: 401 });

    const { extractedText } = await req.json();
    if (!extractedText || typeof extractedText !== "string") {
      return NextResponse.json({ error: "extractedText is required" }, { status: 400 });
    }

    const raw = await askClaude({
      system: BILL_ANALYZER_PROMPT,
      user: extractedText,
      tier: "reasoning",
      maxTokens: 3000,
    });
    const analysis = parseJsonResponse<BillAnalysis>(raw);

    // Only draft a letter if something was actually flagged.
    let disputeLetter: string | null = null;
    if (analysis.flags.length > 0) {
      disputeLetter = await askClaude({
        system: DISPUTE_LETTER_PROMPT,
        user: JSON.stringify({ document_type: analysis.document_type, billing_party: analysis.billing_party, flags: analysis.flags }),
        tier: "reasoning",
        maxTokens: 800,
      });
    }

    // Persist to Supabase so the result survives a page refresh.
    const supabase = supabaseServer();
    const { error: dbError } = await supabase.from("bill_analyses").insert({
      user_id: user.id,
      document_type: analysis.document_type,
      billing_party: analysis.billing_party,
      flags: analysis.flags,
      dispute_letter: disputeLetter,
      confidence: analysis.confidence,
    });
    if (dbError) console.error("bill_analyses insert failed", dbError);

    return NextResponse.json({ analysis, disputeLetter });
  } catch (err) {
    console.error("bill-analyzer error", err);
    return NextResponse.json({ error: "Analysis failed" }, { status: 500 });
  }
}
