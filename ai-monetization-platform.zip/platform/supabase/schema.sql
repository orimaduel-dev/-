-- Core schema + Row-Level Security. Run in Supabase SQL editor.
-- RLS ensures every user can only read/write their own rows —
-- required since API routes use the per-user session client (supabaseServer),
-- not the service-role client.

create table if not exists bill_analyses (
  id uuid primary key default gen_random_uuid(),
  user_id uuid references auth.users(id) not null,
  document_type text,
  billing_party text,
  flags jsonb,
  dispute_letter text,
  confidence text,
  created_at timestamptz default now()
);

create table if not exists app_builder_sessions (
  id uuid primary key default gen_random_uuid(),
  user_id uuid references auth.users(id) not null,
  transcript jsonb,
  spec jsonb,
  generated_html text,
  created_at timestamptz default now()
);

create table if not exists content_niche_results (
  id uuid primary key default gen_random_uuid(),
  user_id uuid references auth.users(id) not null,
  inputs jsonb,
  result jsonb,
  created_at timestamptz default now()
);

create table if not exists b2b_positioning_results (
  id uuid primary key default gen_random_uuid(),
  user_id uuid references auth.users(id) not null,
  inputs jsonb,
  result jsonb,
  created_at timestamptz default now()
);

-- Enable RLS on every table.
alter table bill_analyses enable row level security;
alter table app_builder_sessions enable row level security;
alter table content_niche_results enable row level security;
alter table b2b_positioning_results enable row level security;

-- One policy set per table: user can select/insert/update/delete only their own rows.
create policy "own rows only" on bill_analyses for all
  using (auth.uid() = user_id) with check (auth.uid() = user_id);

create policy "own rows only" on app_builder_sessions for all
  using (auth.uid() = user_id) with check (auth.uid() = user_id);

create policy "own rows only" on content_niche_results for all
  using (auth.uid() = user_id) with check (auth.uid() = user_id);

create policy "own rows only" on b2b_positioning_results for all
  using (auth.uid() = user_id) with check (auth.uid() = user_id);
